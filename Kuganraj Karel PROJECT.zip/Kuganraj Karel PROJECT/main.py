from karel.stanfordkarel import *

def main():
    move()
    for i in range(10):
        put_beeper()
    move()
    for i in range(10):
        put_beeper()
    move()

    paint_corner('Red')
    move()
    paint_corner('Orange')
    move()
    paint_corner('Yellow')
    move()
    paint_corner('Green')
    move()
    paint_corner('Blue')
    move()
    turn_left()
    move()
    move()
    for i in range(4):
        # Put beeper
        put_beeper()

        # Makes us move in a square motion when we do it four times
        move()
        turn_left()
    move()
    move()
    paint_corner('Red')
    move()
    paint_corner('Orange')
    move()
    paint_corner('Yellow')
    move()
    paint_corner('Green')
    move()
    paint_corner('Blue')
    move()
    turn_left()
    move()
    move()
    paint_corner('Red')
    move()
    paint_corner('Orange')
    move()
    paint_corner('Yellow')
    move()
    paint_corner('Green')
    move()
    paint_corner('Blue')
    move()
    turn_left()
    move()
    move()
    paint_corner('Red')
    move()
    paint_corner('Orange')
    move()
    paint_corner('Yellow')
    move()
    paint_corner('Green')
    move()
    paint_corner('Blue')
    move()
    for i in range(2):
        put_beeper()
    move()
    for i in range(2):
        put_beeper()
    turn_left()
    move()
    for i in range(2):
        move()
    turn_left()
    move()
    paint_corner('Red')
    move()
    paint_corner('Orange')
    move()
    paint_corner('Yellow')
    move()
    paint_corner('Green')
    move()
    paint_corner('Blue')
    move()
    turn_left()
    move()
    turn_left()
    for i in range(6):
        move()
    turn_left()
    for i in range(5):
        move()
    for i in range(3):    
        turn_left()
    move()
    turn_left()
    move()
    turn_left()
    while front_is_clear():  # Since we don't know how many squares we need to invert, use a while-loop
        move()
        invert_corner()  # Invert each corner as we move


def invert_corner():
    if beepers_present():
        pick_beeper()
        turn_left()
    else:
        put_beeper()
    


# don't change this code
if __name__ == '__main__':
    main()