import random

def main():
    secret_number = random.randint(1, 10)

    print("Welcome to the Secret Number Guessing Game!")
    print("I am thinking of a number between 1 and 10.")

    guess = 0

    while guess != secret_number:
        guess = int(input("Enter your guess: "))

        if guess == secret_number:
            print("Congratulations! You guessed correctly!")
        elif guess < secret_number:
            print("Too low! Try again.")
        else:
            print("Too high! Try again.")

    print("Thanks for playing!")

if __name__ == "__main__":
    main()